﻿namespace clearTask.Server
{
    public static class Utils
    {
        public static string homeList = "HOME";
    }
}

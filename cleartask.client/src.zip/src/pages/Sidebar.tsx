    import React, { useState, useEffect } from 'react';
    import '../styles/Sidebar.css'; // Import the Sidebar styles
    //import { getAllLists, createList, TaskList } from '../services/taskService';
    //import { addNewList, fetchAllList } from '../services/listService'; // Import the reusable functions
    //import useStore from '../store';

    interface SidebarProps {
        selectedList: string;
        setSelectedList: (list: string) => void;
    }

    const Sidebar: React.FC<SidebarProps> = ({ selectedList, setSelectedList }) => {
        const [lists, setLists] = useState<string[]>([]);
        //const [listIdsAndNames, setListIdsAndNames] = useState<List[]>([]);
        const userId = sessionStorage.getItem('userid') || '';

        useEffect(() => {
        //    fetchAllList(userId, setLists, setListIdsAndNames); // Load lists on component mount
        }, [userId]);

        const handleListClick = (list: string) => {
            setSelectedList(list);
        };

        //const handleNewList = async () => {
        //    const listName = prompt('Enter a new list name:') || '';
        //    await addNewList(listName, userId, lists, setLists, createList);
        //};

        return (
            <div className="sidebar">
                <h3>Lists</h3>
                <ul className="list-items">
                    {lists.map((list) => (
                        <li
                            key={list}
                            className={selectedList === list ? 'active-list' : ''}
                            onClick={() => handleListClick(list)}
                        >
                            {list}
                        </li>
                    ))}
                </ul>
                {/*<button className="new-list-button" onClick={handleNewList}>*/}
                {/*    New List*/}
                {/*</button>*/}
            </div>
        );
    };

    export default Sidebar;
